﻿namespace RAPSimple.Models
{
    public enum FileType
    {
        Avatar = 1, Photo, Background, Logotype
    }
}